    <div class="header_img">
      <img src="Img/Logo.gif">
      <h2> Hotel Royal Gardens</h2>
    </div>
    <div class="header_links">
      <div class="bx bx-menu" id="menu-icon"></div>
      <ul class="navbar">
        <li><a href="#">Kandy</a></li>
        <li><a href="#">Hikkaduwa</a></li>
        <li><a href="#">Trinco</a></li>
        <li><a href="#">Yala</a></li>
        <img class="nav_img" src="Img/Logo.gif">
      </ul>
    </div>